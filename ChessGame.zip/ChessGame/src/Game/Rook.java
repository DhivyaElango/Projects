package Game;

import java.util.HashMap;

public class Rook implements coins {
	int power;char alpha;
static Rook RIns = new Rook();
	public void setPower()
	{
	power=10;
	}
	public int getPower()
	{
		return power;
	}
	public void setAlpha()
	{
	alpha = 'R';
	}
	public char getAlpha()
	{
		return alpha;
	}
	public void move(String next)
	{
		
	}
	
	public static Rook getInstance() {
		// TODO Auto-generated method stub
		return RIns;
	}
	@Override
	public boolean isValid(String color, HashMap<String, String> chessBoard, String next) {
		// TODO Auto-generated method stub
		return false;
	}

}
