package Game;

import java.util.HashMap;

public class Night implements coins {
	int power;
	char alpha;
	static Night NIns = new Night();
	@Override
	public void setPower() {
		// TODO Auto-generated method stub
		power=3;
	}

	@Override
	public int getPower() {
		// TODO Auto-generated method stub
		return power;
	}

	@Override
	public void setAlpha() {
		// TODO Auto-generated method stub
		alpha='N';
	}

	@Override
	public char getAlpha() {
		// TODO Auto-generated method stub
		return alpha;
	}

	@Override
	public void move(String next) {
		// TODO Auto-generated method stub
		
	}

	
	public static Night getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValid(String color, HashMap<String, String> chessBoard, String next) {
		// TODO Auto-generated method stub
		return false;
	}

}
