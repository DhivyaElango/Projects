package Game;

import java.util.HashMap;

public class Pawn implements coins {
	int power;char alpha;
	ChessGame cg = new ChessGame();
	static HashMap<String,String> pawnTrack=new HashMap<String,String>();
static Pawn PIns = new Pawn();
public static void trackPawnMoves()
{
	pawnTrack.put("a2","w.p");
	pawnTrack.put("b2","w.p");
	pawnTrack.put("c2","w.p");
	pawnTrack.put("d2","w.p");
	pawnTrack.put("e2","w.p");
	pawnTrack.put("f2","w.p");
	pawnTrack.put("g2","w.p");
	pawnTrack.put("h2","w.p");
	pawnTrack.put("a7","b.p");
	pawnTrack.put("b7","b.p");
	pawnTrack.put("c7","b.p");
	pawnTrack.put("d7","b.p");
	pawnTrack.put("e7","b.p");
	pawnTrack.put("f7","b.p");
	pawnTrack.put("g7","b.p");
	pawnTrack.put("h7","b.p");

	
}
	public void setPower()
	{
	power=1;
	}
	public int getPower()
	{
		return power;
	}
	public void setAlpha()
	{
	alpha = 'p';
	}
	public char getAlpha()
	{
		return alpha;
	}
	@Override
	public boolean isValid(String color,HashMap<String, String> chessBoard, String next)
	{
		int nextLen = next.length(),num1=0,num2=0;
		char nextChar = next.charAt(1);
		char eachChar = next.charAt(0);
		String label=null,Xlabel=null,colorEnd=null,XcolorEnd=null,pos1=null,pos2=null;
		int lNum = 0,fnum=0;
		if(!next.contains("="))
			lNum = Integer.parseInt(next.charAt(nextLen-1)+"");
		
		if(color.equals("white"))
		{
			if(nextChar!='x' && nextChar!='X')
				num2=num1 = Integer.parseInt(nextChar+"")-1;
			label="w.";//to check piece belongs to white
		//allow double step only from the position 2 for black
			if(num1==3)
				num2 = num1-1;
			fnum = lNum-1;
			label="w.";	Xlabel="b."; colorEnd="8";	XcolorEnd = "7";
		}
		else
		{
			if(nextChar!='x' && nextChar!='X')
				num2=num1 = Integer.parseInt(nextChar+"")+1;
			label="b.";//to check for piece belongs to black
			//allow double step only from the position 7 for black
			if(num1==6)
			num2 = num1+1;
			fnum = lNum+1;
			label="b.";	Xlabel="w."; colorEnd="1"; XcolorEnd="2";
		}	
		if(nextLen<=3)
		{
			
			
			String key1 = eachChar+""+nextChar+"";
			String key2 = eachChar+""+num1+"";
			String key3 = eachChar+""+num2+"";
			System.out.println(chessBoard.get(key1)+" "+key1);
			System.out.println(chessBoard.get(key2)+" "+key2);
			//cg.display();
			System.out.println(chessBoard.get(key3)+" "+key3);
			
			if(chessBoard.get(key1)=="-" && nextLen==2)
			{
				if(chessBoard.get(key2).contains(label) && chessBoard.get(key2).charAt(2)=='p')
				{
					chessBoard.put(key1,chessBoard.get(key2));
					chessBoard.put(key2,"-" );
					
					pawnTrack.put(key1, color.charAt(0)+".p");
					pawnTrack.remove(key2);
					//cg.display(chessBoard);
					return true;
				}
				else if(key2!=key3 && chessBoard.get(key3).contains(label) && chessBoard.get(key3).charAt(2)=='p')
				{
					chessBoard.put(key1,chessBoard.get(key3));
					chessBoard.put(key3, "-");
					
					pawnTrack.put(key1, color.charAt(0)+".p");
					pawnTrack.remove(key3);
					//cg.display(chessBoard);
					return true;
				}
			}}
		//coin X coin shd remove a coin and update move in chessBoard
		else if(nextLen>2 && (nextChar=='x' || nextChar=='X') && !next.contains("="))
			{
				
				
				
				pos1 = next.charAt(0)+""+fnum;
				pos2 = next.charAt(2)+""+lNum;
				String ccutPos2 = next.charAt(2)+""+fnum;
				
				//check capturing and attacking pawn position and confirm they shd be neighbours
				if(chessBoard.get(pos1).contains(label) && chessBoard.get(pos2).contains(Xlabel) && cg.isNeighbour(pos1,pos2))
				{	
					String dead = chessBoard.get(pos2);
					cg.findDeath(dead, color);
					chessBoard.put(pos1, "-");
					chessBoard.put(pos2, color.charAt(0)+".p");
					return true;
				}
				//cross-open with pawns
				else if(chessBoard.get(pos1).contains(label) && chessBoard.get(ccutPos2).contains(Xlabel) && cg.isNeighbour(pos1,ccutPos2))
				{
					if(cg.checkCrossOpen(pos1,ccutPos2,next))
					{
						chessBoard.put(pos1, "-");
						chessBoard.put(ccutPos2, "-");
						chessBoard.put(pos2, color.charAt(0)+".p");
						return true;
					}
						
				}
				
			}
		//pawn reaching end position
		else if(nextLen>2 && next.contains(colorEnd+"="))
			{
				char newPiece=next.charAt(next.length()-1);
				if(newPiece=='Q' || newPiece=='B' || newPiece=='N' || newPiece=='R')
				{
				pos1 = next.charAt(0)+XcolorEnd;
				pos2 = next.charAt(0)+""+next.charAt(1);
				if(next.charAt(1)=='x' || next.charAt(1)=='X')
					{
					pos2 = next.charAt(2)+colorEnd;
					String dead = chessBoard.get(pos2);
					cg.findDeath(dead, color);
					}
				
				chessBoard.put(pos1, "-");
				chessBoard.put(pos2, color.charAt(0)+"."+newPiece);
				return true;
				}
			}
			
		
		
		
		return false;
		
	}
	
	public static Pawn getInstance() {
		// TODO Auto-generated method stub
		
		return PIns;
	}
	@Override
	public void move(String x) {
		// TODO Auto-generated method stub
		
	}


}
