package Game;

import java.util.HashMap;

public class Bishop implements coins {
	int power;
    char alpha;
 static Bishop BIns = new Bishop();
	public void setPower()
	{
	power=3;
	}
	public int getPower()
	{
		return power;
	}
	public void setAlpha()
	{
	alpha = 'K';
	}
	public char getAlpha()
	{
		return alpha;
	}
	public void move(String next)
	{
		
	}
	
	public static Bishop getInstance() {
		// TODO Auto-generated method stub
		
		return BIns;
	}
	@Override
	public boolean isValid(String color, HashMap<String, String> chessBoard, String next) {
		// TODO Auto-generated method stub
		return false;
	}
	}