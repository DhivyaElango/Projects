package Game;

import java.util.HashMap;

public interface coins {
public void setPower();
public int getPower();
public void setAlpha();
public char getAlpha();
public void move(String x);

boolean isValid(String color, HashMap<String, String> chessBoard, String next);

}
