package Game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class ChessGame {
	static Boolean start = Boolean.FALSE;
	static Boolean end = Boolean.FALSE;
	static HashMap<String,String> chessBoard = new HashMap<String,String>();
	static HashMap<Integer,String> moves = new HashMap<Integer,String>();
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	String user1 = null, user2 = null;
	static String nextMove=null,piece=null,whiteMove=null,blackMove=null;
	public char[] pi={'a','b','c','d','e','f','g','h'};
	static int count=0;
	static int countTemp=0;
	
	public static coins obj = null;
	/*public enum identifyCoin {
		  K {
		    public void getObject() {
		      King obj = (King) King.getInstance();
		      System.out.println(obj);
		      piece = "King";
		    }
		  },
		  Q {
		    public void getObject() {
		      Queen obj = (Queen) Queen.getInstance();
		      piece = "Queen";
		    }
		  },
		  R {
		    public void getObject() {
		    	Rook obj = (Rook) Rook.getInstance();
		    }
		  },
		  N {
			    public void getObject() {
			    	Night obj = (Night) Night.getInstance();
			    }
		  },
		  B {
		    public void getObject() {
		    	Bishop obj = Bishop.getInstance();
		    }
		    
			    
				    };

		  public abstract void getObject();
		}*/

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		ChessGame cg =new ChessGame();
		if(start==Boolean.FALSE)
		{count=1;;
			cg.placeCoin();
			cg.display(chessBoard);
			cg.getUserDetails();
			while(!end.booleanValue())
			{obj = null; String color=null,color1 = "white",color2 = "black";
			
			if(count%2==0)
			{countTemp=count;color=color2;
				
			}
			else
				{countTemp=count+1;color=color1;
				
				}
			System.out.print("Enter "+color+" move no:"+countTemp/2+"-->");
				nextMove = br.readLine();
				if(nextMove == "xx")
					end=Boolean.TRUE;
				
				switch(nextMove.charAt(0))
				{
				case 'K':
				{
					//King king=(king)c.newInstance();
				
					obj=King.getInstance();
					break;
				}
				case 'Q':
					obj=Queen.getInstance();
					break;
				case 'B':
					obj=Bishop.getInstance();
					break;
				case 'N':
					obj = Night.getInstance();
					break;
				case 'R':
					obj=Rook.getInstance();
					break;
				default:
					obj=Pawn.getInstance();
				
				}
				/*try
				{
				identifyCoin ic = identifyCoin.valueOf(nextMove.charAt(0)+"");
				ic.getObject();
				System.out.println(obj);
				}
				catch(Exception e)
				{
					System.out.println("Moving pawn???...(y/n)");
					String val=br.readLine();
					
					if(val.equals("y"))
						//obj = (Pawn) Pawn.getInstance();
						{Pawn p1 = new Pawn();
					if(p1.isValid(color,chessBoard,nextMove))
						cg.display(chessBoard);}
				}
				*/
				if(obj.isValid(color, chessBoard, nextMove))
				{
					if(whiteMove==null)
						whiteMove=nextMove+", ";
					else
					{
						moves.put(countTemp,whiteMove+nextMove);
						System.out.println("Moves notation copied....."+moves.get(countTemp));
						whiteMove=null;
					}
					cg.display(chessBoard);
					count++;
				}
				else
					System.out.println("INVALID MOVE..Please re-enter the move...");
				
				
			}
		}

	}
	
	public void display(HashMap<String, String> chessBoard)
	{int i=0,j=0;
	String val = pi[j]+"";
	System.out.println();
	System.out.println();
		for(Map.Entry m:chessBoard.entrySet()){  
			
			i++;
			if(i==9)
			   {
			System.out.println();i=1;j++;
			val = pi[j]+"";
			  }  
			
			String key=val+i+"";
			//System.out.println(key);
			   System.out.print(" "+chessBoard.get(key)); 
		}
			   
	}
	//Find captured piece and display in the console.....
	public void findDeath(String note,String color)
	{char f=note.charAt(0);String dclr=null;
	if(color=="white")
		dclr = "Black";
	else
		dclr = "White";
	switch(f)
	{
	case 'K':
		System.out.println(dclr+" King captured....");break;
	case 'Q':
		System.out.println(dclr+" Queen captured...");break;
	case 'B':
		System.out.println(dclr+" Bishop captured..");break;
	case 'N':
		System.out.println(dclr+" Night captured..");break;
	case 'R':
		System.out.println(dclr+" Rook captured..");break;
	default:
		System.out.println(dclr+" pawn captured...");break;
	}
		
	}
	private void getUserDetails() {
		try {
System.out.print("Enter White User Name : ");
			user1 = br.readLine();
		
		System.out.print("Enter Black User Name : ");
			user2 = br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void placeCoin()
	{
		chessBoard.put("a1", "w.R");
		chessBoard.put("b1", "w.N");
		chessBoard.put("c1", "w.B");
		chessBoard.put("d1", "w.Q");
		chessBoard.put("e1", "w.K");
		chessBoard.put("f1", "w.B");
		chessBoard.put("g1", "w.N");
		chessBoard.put("h1", "w.R");
		
		chessBoard.put("a2", "w.p");
		chessBoard.put("b2", "w.p");
		chessBoard.put("c2", "w.p");
		chessBoard.put("d2", "w.p");
		chessBoard.put("e2", "w.p");
		chessBoard.put("f2", "w.p");
		chessBoard.put("g2", "w.p");
		chessBoard.put("h2", "w.p");
			
		chessBoard.put("a3", "-");
		chessBoard.put("b3", "-");
		chessBoard.put("c3", "-");
		chessBoard.put("d3", "-");
		chessBoard.put("e3", "-");
		chessBoard.put("f3", "-");
		chessBoard.put("g3", "-");
		chessBoard.put("h3", "-");
		
		chessBoard.put("a4", "-");
		chessBoard.put("b4", "-");
		chessBoard.put("c4", "-");
		chessBoard.put("d4", "-");
		chessBoard.put("e4", "-");
		chessBoard.put("f4", "-");
		chessBoard.put("g4", "-");
		chessBoard.put("h4", "-");
		
		chessBoard.put("a5", "-");
		chessBoard.put("b5", "-");
		chessBoard.put("c5", "-");
		chessBoard.put("d5", "-");
		chessBoard.put("e5", "-");
		chessBoard.put("f5", "-");
		chessBoard.put("g5", "-");
		chessBoard.put("h5", "-");
		
		chessBoard.put("a6", "-");
		chessBoard.put("b6", "-");
		chessBoard.put("c6", "-");
		chessBoard.put("d6", "-");
		chessBoard.put("e6", "-");
		chessBoard.put("f6", "-");
		chessBoard.put("g6", "-");
		chessBoard.put("h6", "-");
		
		chessBoard.put("a7", "b.p");
		chessBoard.put("b7", "b.p");
		chessBoard.put("c7", "b.p");
		chessBoard.put("d7", "b.p");
		chessBoard.put("e7", "b.p");
		chessBoard.put("f7", "b.p");
		chessBoard.put("g7", "b.p");
		chessBoard.put("h7", "b.p");
		
		chessBoard.put("a8", "b.R");
		chessBoard.put("b8", "b.N");
		chessBoard.put("c8", "b.B");
		chessBoard.put("d8", "b.Q");
		chessBoard.put("e8", "b.K");
		chessBoard.put("f8", "b.B");
		chessBoard.put("g8", "b.N");
		chessBoard.put("h8", "b.R");
		
		Pawn.trackPawnMoves();
	}
	public boolean isNeighbour(String pos1, String pos2) {
		for(int i=0;i<pi.length-2;i++)
			if(pi[i]==pos1.charAt(0) || pi[i]==pos2.charAt(0))
				if(pi[i+1]==pos1.charAt(0) || pi[i+1]==pos2.charAt(0))
					return true;
		// TODO Auto-generated method stub
		return false;
	}
	public boolean checkCrossOpen(String pos1, String pos2, String next) {
		// TODO Auto-generated method stub
		
		String lastMove=pos2;
		//System.out.println("whitemove=="+whiteMove);
		if(whiteMove!=null && whiteMove.contains(lastMove))
			return true;
		else
		{/*System.out.println(moves.get(countTemp-2));
			System.out.println(moves.get(countTemp-1));
			System.out.println("pos2--->"+pos2);*/
			if(moves.get(countTemp-2).contains(lastMove))
					return true;
		}
		return false;
	}

}
