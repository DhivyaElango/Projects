package Game;

import java.util.HashMap;

public class King implements coins {
int power;char alpha;
ChessGame cg = new ChessGame();
private static final King KIns = new King();
public static String bPosition="e8", wPosition="e1";
public void setPower()
{
power=10;
}
public int getPower()
{
	return power;
}
public void setKingPos(char color,String pos)
{
if(color=='w')
	wPosition=pos;
else
	bPosition=pos;
}
public String getKingPos(char color)
{
	if(color=='w')
		return wPosition;
	else
		return bPosition;
}
public void setAlpha()
{
alpha = 'K';
}
public char getAlpha()
{
	return alpha;
}
public void move(String next)
{
	
}
public static King getInstance() {
	
	return KIns;
}
@Override
public boolean isValid(String color, HashMap<String, String> chessBoard, String next) {
	// TODO Auto-generated method stub
	int nextLen = next.length(),num1=0,num2=0;
	String label=null,Xlabel=null,colorEnd=null,XcolorEnd=null,pos1=null,pos2=null;
	char nextChar = next.charAt(1);
	pos1=getKingPos(color.charAt(0));
	
	if(color.equals("white"))
	{
		
		label="w.";	Xlabel="b."; 
		
	}
	else
	{
		
		label="b.";	Xlabel="w."; 
	}	
	
	
	if(nextLen==3)
	{
		pos2 = next.charAt(1)+""+next.charAt(nextLen-1);
		if(chessBoard.get(pos1).contains(label) && chessBoard.get(pos2)=="-" && (cg.isNeighbour(pos1,pos2)||isNextPos(pos1,pos2)))
			{
			chessBoard.put(pos1, "-");
		chessBoard.put(pos2, color.charAt(0)+".K");
		setKingPos(color.charAt(0),pos2);
		return true;
			}
		
	}
	else if(nextLen>3 && (nextChar=='x' || nextChar=='X') )
	{
		pos2 = next.charAt(2)+""+next.charAt(nextLen-1);
		if(chessBoard.get(pos1).contains(label) && chessBoard.get(pos2).contains(Xlabel) && cg.isNeighbour(pos1,pos2))
		{	
			String dead = chessBoard.get(pos2);
			cg.findDeath(dead, color);
			chessBoard.put(pos1, "-");
			chessBoard.put(pos2, color.charAt(0)+".K");
			return true;
		}
	}
	return false;
}
private boolean isNextPos(String pos1, String pos2) {
	// TODO Auto-generated method stub
	if(pos1.charAt(0)==pos2.charAt(0))
	{
		int num1=Integer.parseInt(pos1.charAt(1)+"");
		int num2=Integer.parseInt(pos2.charAt(1)+"");
		if(Math.abs(num2-num1)==1)
			return true;
	}
	return false;
}
}