package Game;

import java.util.HashMap;

public class Queen implements coins {
	int power;
	char alpha; 
	static Queen QIns = new Queen();
	public void setPower()
	{
	power=9;
	}
	public int getPower()
	{
		return power;
	}
	public void setAlpha()
	{
	alpha = 'Q';
	}
	public char getAlpha()
	{
		return alpha;
	}
	public void move(String next)
	{
		
	}
	
	public static Queen getInstance() {
		// TODO Auto-generated method stub
		return QIns;
	}
	@Override
	public boolean isValid(String color, HashMap<String, String> chessBoard, String next) {
		// TODO Auto-generated method stub
		return false;
	}
	}
